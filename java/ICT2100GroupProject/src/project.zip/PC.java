import java.util.ArrayList;

public class PC implements Printable, SoftwareModifier {
    private String name;
    private IPv4 ip;
    private String computerType;
    private int yearManufacture;
    private double ramRequirement;
    private String labName;
    private ArrayList<Software> softwareList;
    
    //default constructor 
    public PC(){
        this("",new IPv4(),"",0,0,"");
    }

    /**
     * Copy constructor to create a new object with same value as the parameter object
     * @param obj the object to be copy
     */
    public PC(PC obj){
        this(obj.getName(),obj.getIp(),obj.getComputerType(),
                obj.getYearManufacture(),obj.getRamRequirement(),obj.getLabName());
    }
    
    //Overloaded Constructor
    public PC (String n, IPv4 ip, String ct, int ym, double r){
        this(n,ip,ct,ym,r,"");
    }
    public PC (String n,String ip){
        this.setName(n);
        this.setIp(ip);
        this.softwareList = new ArrayList<Software>();
    }
    public PC (String n, IPv4 ip, String ct, int ym, double r, String lb){
        this.setName(n);
        this.setIp(ip);
        this.setComputerType(ct);
        this.setYearManufacture(ym);
        this.setRamRequirement(r);
        this.setLabName(lb);
        this.softwareList = new ArrayList<Software>();
    }
    
     //Mutator method
    public void setName(String n){
        if(n==null || n.trim().equals(""))
            this.name = "unknown name";
        else
            this.name = n;
    }
    public void setIp(IPv4 ip){
        if(ip==null)
            this.ip = new IPv4();
        else
            this.ip = ip;
    }
    public void setIp(String ip){
        if(ip == null || ip.trim().equals(""))
            this.ip = new IPv4();
        else
            this.ip = new IPv4(ip);
    }
    public void setComputerType(String ct){
        if(ct==null || ct.trim().equals(""))
            this.computerType="--";
        else
            this.computerType = ct;
    }
    public void setYearManufacture(int ym){
        if(ym<1000 || ym>9999)
            this.yearManufacture = 1000;
        else
            this.yearManufacture = ym;
    }
    public void setRamRequirement(double r){
        if(r<0 || r>64)
            this.ramRequirement = 0;
        else
            this.ramRequirement = r;
    }
    public void setLabName(String lb){
        if(lb==null || lb.trim().equals(""))
            this.labName = "--";
        else
            this.labName = lb;
    }
    
    //Accessor method
    public String getName(){ return name; }
    public IPv4 getIp(){ return ip; }
    public String getComputerType(){ return computerType; }
    public int getYearManufacture(){ return yearManufacture; }
    public double getRamRequirement(){ return ramRequirement; }
    public String getLabName(){ return labName; }

    @Override
    public void printSoftwareList() {
        int size = softwareList.size();
        System.out.printf("%-6s|%-30s\n","Index","Software");
        System.out.println("------------------------------");
        for(int i=0;i<size;++i){
            System.out.printf("%-6d|%-30s\n",i+1,softwareList.get(i).getName());
        }
    }

    @Override
    public void addSoftware(Software s){
        softwareList.add(new Software(s));
    }

    @Override
    public void removeSoftware(Software s){
        softwareList.remove(s);
    }

    @Override
    public void removeSoftware(int index) {
        softwareList.remove(index);
    }

    @Override
    public boolean hasSoftware(Software s){
        for(int i=0;i<softwareList.size();++i){
            if (s.equals(softwareList.get(i))){
                return true;
            }
        }

        return false;
    }

    @Override
    public Software getSoftware(Software s) {
        int index = -1;
        for(Software software:softwareList){
            if(software.equals(s)){
                index = 0;
                break;
            }
        }

        return softwareList.get(index);
    }

    @Override
    public Software getSoftware(int index) {
        return softwareList.get(index);
    }

    @Override
    public int getNumSoftware() {
        return softwareList.size();
    }

    @Override
    public String toString(){
        return (getName() + "," + getIp().toString() + "," + getComputerType() + "," +
                getYearManufacture() + "," + getRamRequirement() + "," + getLabName());
    }

    @Override
    public boolean equals(Object obj){
        if(!(obj instanceof PC)){
            return false;
        }

        boolean result = false;

        PC temp = (PC) obj;
        if(temp.getName().equals(this.name)||temp.getIp().toString().equals(this.ip.toString())){
            result = true;
        }

        return result;
    }

    @Override
    public void print(){
        System.out.println("Name:"+this.name);
        System.out.println("IPv4:"+this.ip);
        System.out.println("Computer type:"+this.computerType);
        System.out.println("Year of manufacture:"+this.yearManufacture);
        System.out.println("Ram requirement:"+this.ramRequirement);

        if(labName.equals("--"))
            System.out.println("This pc is not under any of the IT Lab.");
        else
            System.out.println("Lab name:"+this.labName);

        System.out.println("Software List:");
        System.out.printf("%-6s|%-30s|%-10s\n","Index","Software Name","Ram Req.(GB)");
        System.out.println("----------------------------------------");
        for(int i=0;i<softwareList.size();++i){
            System.out.printf("%-6d|%-30s|%-10.2f\n",i+1,softwareList.get(i).getName(),softwareList.get(i).getRamRequirement());
        }
    }

}

