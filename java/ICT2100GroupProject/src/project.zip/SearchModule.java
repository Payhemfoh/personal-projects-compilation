import java.util.ArrayList;

public class SearchModule {
    /**
     * This method will enter the search module which search the object in the list and print out the details of the object
     * @param labList The Array List of the ITLab object
     * @param pcList The Array List of the PC object
     * @param softwareList The Array List of the Software object
     */
    public static void enterSearchModule(ArrayList<ITLab> labList, ArrayList<PC> pcList, ArrayList<Software> softwareList) {
        boolean isContinue = true;
        int option = 0;
        do {

            PrintModule.printSearchMenu();
            option = InputModule.getIntegerInput("Option:");

            switch (option) {
                case 1:
                    searchITLab(labList);
                    break;
                case 2:
                    searchPC(pcList);
                    break;
                case 3:
                    searchSoftware(softwareList);
                    break;
                case 4:
                    System.out.println("Returning to the Main Module...\n");
                    isContinue = false;
                    break;
                default:
                    System.out.println("Invalid input! please try again!");
            }

        } while (isContinue);
    }

    private static void searchITLab(ArrayList<ITLab> list){
        boolean isContinue = true;
        int option = 0;
        do{
            PrintModule.printSearchLabMenu();
            option = InputModule.getIntegerInput("Option:");

            switch(option){
                case 1:
                    searchITLabByName(list);
                    break;
                case 2:
                    searchITLabByNumPC(list);
                    break;
                case 3:
                    System.out.println("Returning to search module...\n");
                    isContinue = false;
                    break;
                default:
                    System.out.println("Invalid input! Please try again!");
            }
        }while(isContinue);
    }

    private static void searchSoftware(ArrayList<Software> list){
        boolean isContinue = true;
        int option = 0;
        do{
            PrintModule.printSearchSoftwareMenu();
            option = InputModule.getIntegerInput("Option:");

            switch(option){
                case 1:
                    searchSoftwareByName(list);
                    break;
                case 2:
                    searchSoftwareByType(list);
                    break;
                case 3:
                    searchSoftwareByRam(list);
                    break;
                case 4:
                    searchSoftwareByExpireDate(list);
                    break;
                case 5:
                    System.out.println("Returning to search module...\n");
                    isContinue = false;
                    break;
                default:
                    System.out.println("Invalid input! Please try again!");
            }
        }while(isContinue);
    }

    private static void searchPC(ArrayList<PC> computerList){
        boolean isContinue = true;
        int option = 0;
        do{
            PrintModule.printSearchPCMenu();
            option = InputModule.getIntegerInput("Option:");

            switch(option){
                case 1:
                    searchPCByName(computerList);
                    break;
                case 2:
                    searchPCByIP(computerList);
                    break;
                case 3:
                    searchPCByType(computerList);
                    break;
                case 4:
                    searchPCByYearManufacture(computerList);
                    break;
                case 5:
                    searchPCByRam(computerList);
                    break;
                case 6:
                    searchPCByLabName(computerList);
                    break;
                case 7:
                    System.out.println("Returning to search module...\n");
                    isContinue = false;
                    break;
                default:
                    System.out.println("Invalid input! Please try again!");
            }
        }while(isContinue);
    }

    private static void searchSoftwareByName(ArrayList<Software> list){
        int count = 0;

        String name = InputModule.getStringInput("Enter name of software:");
        for (Software software : list) {
            if (name.equals(software.getName())) {
                software.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No Software which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchSoftwareByRam(ArrayList<Software> list){
        int count = 0;
        double ram = InputModule.getRamInput("Enter Ram Requirement of the Software:");

        for (Software software : list) {
            if (ram == software.getRamRequirement()) {
                software.print();
                ++count;
            }
        }

        if(count==0){
            System.out.println("No Software which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchSoftwareByExpireDate(ArrayList<Software> list){
        int count = 0;

        String date = InputModule.getDateInput();

        for (Software software : list) {
            if (date.equals(software.getExpireDate())) {
                software.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No Software which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchSoftwareByType(ArrayList<Software> list){
        int count = 0;

        String type = InputModule.getSoftwareTypeInput();

        for (Software software : list) {
            if (type.equals(software.getType())) {
                software.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No Software which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchITLabByName(ArrayList<ITLab> list){
        int count = 0;

        String name = InputModule.getStringInput("Enter name of ITLab:");

        for (ITLab itLab : list) {
            if (name.equals(itLab.getName())) {
                itLab.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No ITLab which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchITLabByNumPC(ArrayList<ITLab> list){
        int count = 0;
        int numberPC=0;

        do {
            numberPC = InputModule.getIntegerInput("Enter number of PC in ITLab:");

            if(numberPC<0 || numberPC>50)
                System.out.println("Invalid Input! The number of PC should be in range of [0-50]. Please try again!");
        }while(numberPC<0 || numberPC>50);

        for (ITLab itLab : list) {
            if (numberPC == itLab.getNumComputer()) {
                itLab.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No ITLab which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchPCByName(ArrayList<PC> list){
        int count = 0;

        String name = InputModule.getStringInput("Enter name of PC:");

        for (PC pc : list) {
            if (name.equals(pc.getName())) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchPCByIP(ArrayList<PC> list){
        int count = 0;

        IPv4 ip = InputModule.getIPv4Input();

        for (PC pc : list) {
            if (ip.equals(pc.getIp())) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }

    private static void searchPCByLabName(ArrayList<PC> list){
        int count = 0;

        String labname = InputModule.getStringInput("Enter Lab Name of the PC:");

        for (PC pc : list) {
            if (labname.equals(pc.getLabName())) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }

    public static void searchPCByRam(ArrayList<PC> list){
        int count = 0;
        double ram = InputModule.getRamInput("Enter Ram Requirement of the PC:");

        for (PC pc : list) {
            if (ram == pc.getRamRequirement()) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }

    public static void searchPCByType(ArrayList<PC> list){
        int count = 0;

        String type = InputModule.getPCTypeInput();
        for (PC pc : list) {
            if (type.equals(pc.getComputerType())) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }

    public static void searchPCByYearManufacture(ArrayList<PC> list){
        int count = 0;
        int year = InputModule.getYearInput("Enter year manufacture of the PC:");

        for (PC pc : list) {
            if (year == pc.getYearManufacture()) {
                pc.print();
                ++count;
            }
        }
        if(count==0){
            System.out.println("No PC which meets the requirement.");
        }
        System.out.println();
    }
}
