import java.util.InputMismatchException;

public class IPv4 {
    //private variable of 4 bytes
    private int byte1;
    private int byte2;
    private int byte3;
    private int byte4;

    /**
     * Default constructor which create IPv4 object with initial value of 0.0.0.0
     */
    public IPv4(){
        this(0,0,0,0);
    }

    //overloaded constructor
    public IPv4(int byte1,int byte2,int byte3,int byte4){
        setByte1(byte1);
        setByte2(byte2);
        setByte3(byte3);
        setByte4(byte4);
    }
    public IPv4(String ip){
        String[] block = ip.split("\\.");

        if(block.length!= 4)
            throw new InputMismatchException();

        setByte1(Integer.parseInt(block[0]));
        setByte2(Integer.parseInt(block[1]));
        setByte3(Integer.parseInt(block[2]));
        setByte4(Integer.parseInt(block[3]));
    }
    
    //setter
    public void setByte1(int byte1){
        if(byte1<0||byte1>255)
            this.byte1 = 0;
        else
            this.byte1 = byte1;
    }
    public void setByte2(int byte2){
        if(byte2<0||byte2>255)
            this.byte2 = 0;
        else
            this.byte2 = byte2;
    }
    public void setByte3(int byte3){
        if(byte3<0||byte3>255)
            this.byte3 = 0;
        else
            this.byte3 = byte3;
    }
    public void setByte4(int byte4){
        if(byte4<0||byte4>255)
            this.byte4 = 0;
        else
            this.byte4 = byte4;
    }

    //getter
    public int getByte1(){return this.byte1;}
    public int getByte2(){return this.byte2;}
    public int getByte3(){return this.byte3;}
    public int getByte4(){return this.byte4;}
    
    //override toString
    @Override
    public String toString(){return byte1+"."+byte2+"."+byte3+"."+byte4;}

    //check the duplication of IPv4
    @Override
    public boolean equals(Object obj){
        if(!(obj instanceof IPv4)){
            return false;
        }

        IPv4 temp = (IPv4) obj;
        boolean isEqual = true;

        if(temp.getByte1() != this.getByte1())
            isEqual = false;
        else if(temp.getByte2() != this.getByte2())
            isEqual = false;
        else if(temp.getByte3() != this.getByte3())
            isEqual = false;
        else if(temp.getByte4() != this.getByte4())
            isEqual = false;

        return isEqual;
    }
}
