import java.io.*;
import java.util.ArrayList;

public class HTMLExportationModule {
    public static void export(ArrayList<ITLab> labList,ArrayList<PC> pcList,ArrayList<Software> softwareList){
        try {
            exportTable(labList, pcList, softwareList);
            exportSoftware(softwareList);
            exportPC(pcList);
            exportLab(labList);
            System.out.println("All the output files already saved into the output directory.\n");
        }catch(Exception e){
            System.out.println("Oops! Failed to export the HTML file."+e.getMessage());
        }
    }
    /**
     * This method will export all the data and save into table form in HTML format
     * @param labList the Array List of the ITLab object
     * @param pcList the Array List of the PC object
     * @param softwareList the Array List of the Software object
     */
    public static void exportTable(ArrayList<ITLab> labList,ArrayList<PC> pcList,ArrayList<Software> softwareList){
        File save = new File("./output/GeneralTable.html");
        //path is used to create the directory
        File path = new File("./output");
        try {
            if(!save.exists()) {
                if (!path.exists()) {
                    boolean createDir= path.mkdir();
                    if(createDir)
                        System.out.println("Success to create the directory");
                    else
                        throw new IOException("Failed to create the directory");
                }
                save.createNewFile();
                System.out.println("Success to create the file");
            }
            FileWriter fw = new FileWriter(save);
            PrintWriter pw = new PrintWriter(fw);

            pw.println("<!DOCTYPE html><html lang=\"en\"><head><title>General Table</title><meta charset=\"utf-8\"><body>");


            pw.println("<body>");
            pw.println("<h1> ITLab </h1>");
            pw.println("<table border=\"1\" spacing=\"4\">");
            pw.println("<tr><th>Name</th><th>No.Computer</th></tr>");

            for(ITLab lab : labList){
                pw.println("<tr>");
                pw.printf("<td><a href=\"./Lab.html#%s\">%s</a></td>",lab.getName().replace(' ','_'),lab.getName());
                pw.println("<td>" + lab.getNumComputer() +  "</td>");
                pw.println("</tr>");

            }
            pw.println("</table>");
            pw.println("<br><br>");

            pw.println("<h1> PC </h1>");
            pw.println("<table border=\"1\" spacing=\"4\">");
            pw.println("<tr>");
            pw.println("<th>Name</th><th>IP</th><th>ComputerType</th><th>YearManufacture</th><th>RamRequirement</th><th>LabName</th>");
            pw.println("</tr>");

            for(PC pc : pcList){
                pw.println("<tr>");
                pw.printf("<td><a href=\"./PC.html#%s\">%s</a></td>",pc.getName().replace(' ','_'),pc.getName());
                pw.println("<td>" + pc.getIp() +  "</td>");
                pw.println("<td>" + pc.getComputerType() + "</td>");
                pw.println("<td>" + pc.getYearManufacture() + "</td>");
                pw.println("<td>" + pc.getRamRequirement() + "</td>");
                pw.println("<td>" + pc.getLabName() + "</td>");
                pw.println("</tr>");
            }
            pw.println("</table>");
            pw.println("<br><br>");

            pw.println("<h1> Software </h1>");
            pw.println("<table border=\"1\" spacing=\"4\">");
            pw.println("<tr>");
            pw.println("<th>Name</th><th>Type</th><th>RamRequirement</th><th>ExpireDate</th>");
            pw.println("</tr>");

            for(Software software : softwareList){
                pw.println("<tr>");
                pw.printf("<td><a href=\"./Software.html#%s\">%s</a></td>",software.getName().replace(' ','_'),software.getName());
                pw.println("<td>" + software.getType() +  "</td>");
                pw.println("<td>" + software.getRamRequirement() + "</td>");
                pw.println("<td>" + software.getExpireDate() +"</td>");
                pw.println("</tr>");

            }
            pw.println("</table>");

            pw.println("</body></html>");

            System.out.println("GeneralTable.html exported successfully.\n");
            pw.close();
            fw.close();
        }

        catch(IOException e){
            System.out.println("Failed to open file to write data. Please try again later.");
        }

        catch(Exception e){
            System.out.println("An unexpected error had occur during the process."+e.getMessage());
        }
    }

    public static void exportLab(ArrayList <ITLab> list){
        File save = new File("./output/Lab.html");
        //path is used to create the directory
        File path = new File("./output");
        try {
            if(!save.exists()) {
                if (!path.exists()) {
                    boolean createDir= path.mkdir();
                    if(createDir)
                        System.out.println("Success to create the directory");
                    else
                        throw new IOException("Failed to create the directory");
                }
                save.createNewFile();
                System.out.println("Success to create the file");
            }
            FileWriter fw = new FileWriter(save);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("<!DOCTYPE html>");
            pw.println("<html lang-\"en\">");
            
            pw.println("<head>");
            pw.println("<title>IT Lab</title>");
                pw.println("<meta charset =\"utf-8\">");
            pw.println("</head>");
    
            pw.println("<body>");
            
                for(ITLab List: list){
                    pw.printf("<a name=\"%s\">",List.getName().replace(' ','_'));
                    pw.printf("Name:%s<br>",List.getName());
                    pw.printf("No.Computer:%d<br>",List.getNumComputer());
                    pw.println("<table border=\"1\" spacing=\"3\">");
                    pw.println("<tr><th>Index</th><th>PC Name</th><th>IPv4(GB)</th></tr>");
                    for(int i=0;i<List.getNumComputer();i++){
                        pw.println("<tr>");
                        pw.printf("<td>%d</td>",i+1);
                        pw.printf("<td><a href=\"PC.html#%s\">%s</a></td>",List.getPC(i).getName().replace(' ','_'),List.getPC(i).getName());
                        pw.printf("<td>%s(GB)</td>",List.getPC(i).getIp());
                        pw.print("<tr>");
                    }
                    pw.println("</table></a>");
                    pw.println("<br><br>");
                }
            pw.println("</body>");
            pw.println("</html");

            System.out.println("Lab.html exported successfully.\n");
            pw.close();
            fw.close();
        }catch(IOException e){
            System.out.println("Failed!"+e.getMessage());
            System.exit(-1);
        }
    }
    
    public static void exportPC(ArrayList <PC> list){
        File save = new File("./output/PC.html");
        //path is used to create the directory
        File path = new File("./output");
        try {
            if(!save.exists()) {
                if (!path.exists()) {
                    boolean createDir= path.mkdir();
                    if(createDir)
                        System.out.println("Success to create the directory");
                    else
                        throw new IOException("Failed to create the directory");
                }
                save.createNewFile();
                System.out.println("Success to create the file");
            }
            FileWriter fw = new FileWriter(save);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("<DOCTYPE HTML>");
            pw.println("<html lang-\"en\">");
            
            pw.println("<head>");
            pw.println("<title>PC</title>");
            pw.println("<meta charset =\"utf-8\">");
            pw.println("</head>");
            
            pw.println("<body>");
            for(PC pc: list){
                pw.printf("<a name=\"%s\">",pc.getName().replace(' ','_'));
                pw.printf("Name:%s<br>",pc.getName());
                pw.printf("IPv4:%s<br>",pc.getIp());
                pw.printf("Computer type:%s<br>",pc.getComputerType());
                pw.printf("Year of manufacture:%d<br>",pc.getYearManufacture());
                pw.printf("Ram Requirement:%.2f<br>",pc.getRamRequirement());
                //ternary operator to display the lab name
                pw.printf("Lab Name:%s<br>",pc.getLabName().equals("--")?"This pc is not under any of the IT Lab":pc.getLabName());
                pw.println("<table border=\"1\" spacing=\"3\">");
                pw.println("<tr><th>Index</th><th>Software Name</th><th>Ram Requirement(GB)</th></tr>");
                for(int i=0;i<pc.getNumSoftware();i++){
                    pw.println("<tr>");
                    pw.printf("<td>%d</td>",i+1);
                    pw.printf("<td><a href=\"Software.html#%s\">%s</a></td>",pc.getSoftware(i).getName().replace(' ','_'),pc.getSoftware(i).getName());
                    pw.printf("<td>%.2f(GB)</td>",pc.getSoftware(i).getRamRequirement());
                    pw.print("<tr>");
                }
                pw.println("</table></a>");
                pw.println("<br><br>");
            }

            pw.println("</body>");
            pw.println("</html");

            System.out.println("PC.html exported successfully.\n");
            pw.close();
            fw.close();
        }catch(IOException e){
            System.out.println("Failed!"+e.getMessage());
            System.exit(-1);
        }
    }
    
    
    public static void exportSoftware(ArrayList <Software> list){
        File save = new File("./output/Software.html");
        //path is used to create the directory
        File path = new File("./output");
        try {
            if(!save.exists()) {
                if (!path.exists()) {
                    boolean createDir= path.mkdir();
                    if(createDir)
                        System.out.println("Success to create the directory");
                    else
                        throw new IOException("Failed to create the directory");
                }
                save.createNewFile();
                System.out.println("Success to create the file");
            }
            FileWriter fw = new FileWriter(save);
            PrintWriter pw = new PrintWriter(fw);
            
            pw.println("<!DOCTYPE html>");
            pw.println("<html lang-\"en\">");
            
            pw.println("<head>");
                pw.println("<title>Software</title>");
                pw.println("<meta charset =\"utf-8\">");
            pw.println("</head>");
            
            pw.println("<body>");
                for(Software software: list){
                    pw.printf("<a name=\"#%s\">",software.getName().replace(' ','_'));
                    pw.printf("Name: %s<br>",software.getName());
                    pw.printf("Type: %s<br>",software.getType());
                    pw.printf("Ram Requirement:%.2f GB<br>",software.getRamRequirement());
                    pw.printf("Expire Date: %s<br>",software.getExpireDate());
                    pw.println("</a><br><br>");
                }
            pw.println("</body>");
            pw.println("</html");

            System.out.println("Software.html exported successfully.\n");
            pw.close();
            fw.close();
        }catch(IOException e){
            System.out.println("Failed!"+e.getMessage());
            System.exit(-1);
        }
    }
}