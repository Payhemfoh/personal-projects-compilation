import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class InputModule {
    public static String getStringInput(String prompt){
        boolean isValid = false;
        String input ="";

        Scanner sc = new Scanner(System.in);

        do{
            try {
                System.out.print(prompt);
                input = sc.nextLine().trim();
                System.out.println();
                if (input.equals(""))
                    throw new InputMismatchException();
                else
                    isValid = true;
            }

            catch(InputMismatchException e){
                System.out.println("Invalid input, please try again!");
                isValid = false;
            }
            catch(Exception e){
                System.out.println("An unexpected error had occur during the process!"+e.getMessage());
                isValid = false;
            }
        }while(!isValid);

        return input;
    }

    public static double getDoubleInput(String prompt){
        boolean isValid = false;
        double input = 0.0;
        double stringInput = 0.0;
        Scanner sc = new Scanner(System.in);

        while(!isValid){
            try {
                System.out.print(prompt);
                stringInput = Double.parseDouble(sc.nextLine().trim());
                System.out.println();
                isValid = true;
            }
            catch(InputMismatchException | NumberFormatException e){
                System.out.println("Invalid input, please try again!");
                isValid = false;
            }
            catch(Exception e){
                System.out.println("Oops! An unexpected error had occur during the process."+e.getMessage());
                isValid = false;
            }
        }
        input = Double.parseDouble(String.format("%.2f",stringInput));
        return input;
    }

    public static int getIntegerInput(String prompt){
        boolean isValid = false;
        int input = 0;
        Scanner sc = new Scanner(System.in);

        while(!isValid){
            try {
                System.out.print(prompt);
                input = Integer.parseInt(sc.nextLine().trim());
                System.out.println();
                isValid = true;
            }

            catch(InputMismatchException | NumberFormatException e){
                System.out.println("Invalid input, please try again!");
                isValid = false;
            }
            catch(Exception e){
                System.out.println("Oops! An unexpected error had occur during the process."+e.getMessage());
                isValid = false;
            }
        }
        return input;
    }

    public static String getSoftwareTypeInput(){
        int option = 0;
        String result = "";

        PrintModule.printSoftwareTypeSelectMenu();
        option = getIntegerInput("Option:");
        switch (option) {
            case 1:
                result = "Proprietary";
                break;
            case 2:
                result = "Shareware";
                break;
            case 3:
                result = "Freeware";
                break;
            default:
                System.out.println("Invalid input please try again!");
        }
        return result;
    }

    public static IPv4 getIPv4Input(){
        final int SIZE = 4;
        int blockValue = 0;
        boolean isValid = true;
        int[] bytes = new int[SIZE];
        String[] blocks = null;

        do {
            try {
                String ip = getStringInput("Please enter the IP address [xxx.xxx.xxx.xxx](xxx indicate range of 0-255) :");
                blocks = ip.split("\\.");

                if (blocks.length != SIZE)
                    throw new InputMismatchException();

                for (int i = 0; i < SIZE; ++i) {
                    blockValue = Integer.parseInt(blocks[i]);

                    if (blockValue < 0 || blockValue > 255)
                        throw new InputMismatchException();

                    bytes[i] = blockValue;
                    isValid = true;
                }
            }

            catch (InputMismatchException | NumberFormatException e) {
                System.out.println("Invalid format of IP address! Please try again!");
                isValid = false;
            }catch (Exception e){
                System.out.println("Oops! An unexpected error occur during the process. "+e.getMessage());
                isValid = false;
            }
        }while(!isValid);

        return new IPv4(bytes[0],bytes[1],bytes[2],bytes[3]);
    }

    /**
     * This method is used to get the Character option from the user
     * mainly for the confirmation of edit and delete
     * @return char input used for confirmation of edit and delete
     */
    public static char getCharOption(){
        Scanner sc = new Scanner(System.in);
        boolean isValid = false;
        char input = '\u0000';

        while(!isValid){
            try {
                System.out.print("Option:");
                input = sc.nextLine().trim().charAt(0);
                isValid = true;
            }
            catch(InputMismatchException | StringIndexOutOfBoundsException e){
                System.out.println("Invalid input, please try again!");
                isValid = false;
            }
            catch(Exception e){
                System.out.println("Oops! An unexpected error occur during the process. "+e.getMessage());
                isValid = false;
            }
        }
        return input;
    }

    public static String getPCTypeInput(){
        int option = 0;
        String result = "";

        PrintModule.printPCTypeSelectMenu();
        option = getIntegerInput("Option:");
        switch (option) {
            case 1:
                result = "Desktop";
                break;
            case 2:
                result = "Laptop";
                break;
            default:
                System.out.println("Invalid input please try again!");
        }
        return result;
    }

    public static double getRamInput(String prompt){
        final double LOWEST = 0.01, HIGHEST = 64.00;
        boolean isValid = false;
        double ram = 0.0;
        do {
            try {
                ram = getDoubleInput(prompt);

                if(ram<LOWEST || ram>HIGHEST)
                    throw new InputMismatchException();

                isValid = true;
            }catch(InputMismatchException | NumberFormatException e){
                System.out.printf("Invalid Input! The ram should be in range of [%.2f - %.2f]! Please try again!\n"
                                    ,LOWEST,HIGHEST);
                isValid = false;
            }
            catch(Exception e){
                System.out.println("Oops! An unexpected error had occur during the process."+e.getMessage());
                isValid = false;
            }

        }while(!isValid);

        return ram;
    }

    public static int getYearInput(String prompt){
        int year = 0;
        boolean isValid = false;

        do {
            try {
                year = InputModule.getIntegerInput(prompt);

                if(year<1000 || year>9999)
                    throw new InputMismatchException();

                isValid = true;
            }catch(InputMismatchException e){
                System.out.println("Invalid Input! The year should be in range of [1000 - 9999]! Please try again!");
                isValid = false;
            }
            catch(Exception e){
                System.out.println("Oops! An unexpected error had occur during the process."+e.getMessage());
                isValid = false;
            }
        }while(!isValid);

        return year;
    }

    public static String getDateInput(){
        boolean isValid = false;

        int year = getYearInput("Enter year of software expired:");

        int month = 0,day = 0;

        do {
            month = InputModule.getIntegerInput("Enter month of software expired[1-12]:");
            if(month<1||month>12) {
                System.out.println("Invalid Input! The month should in range of [1 - 12]! Please try again!");
                isValid = false;
            }else{
                isValid = true;
            }
        }while(!isValid);

        do {
            day = InputModule.getIntegerInput("Enter day of software expired:");
            if(MonthConverter.checkDay(day,month)){
                isValid = true;
            }else{
                System.out.println("Invalid Input! There are no day "+day+" in month "+MonthConverter.convertMonth(month));
                isValid = false;
            }
        }while(!isValid);

        return day + "-" + MonthConverter.convertMonth(month)+ "-" + year;
    }

    public static String getLabName(ArrayList<ITLab> list){
        boolean isValid = false;

        String name = "";
        do {
            isValid = true;
            name = InputModule.getStringInput("Enter IT Lab Name:");
            for(ITLab lab : list){
                if(lab.getName().equals(name)){
                    System.out.println("The IT Lab already present in the IT Lab list!");
                    isValid = false;
                    break;
                }
            }
        }while(!isValid);

        return name;
    }

    public static String getPCName(ArrayList<PC> list){
        boolean isValid = false;

        String name = "";
        do {
            isValid = true;
            name = InputModule.getStringInput("Enter PC Name:");
            for(PC pc : list){
                if(pc.getName().equals(name)){
                    System.out.println("The PC already present in the PC list!");
                    isValid = false;
                    break;
                }
            }
        }while(!isValid);

        return name;
    }

    public static String getSoftwareName(ArrayList<Software> list){
        boolean isValid = false;

        String name = "";
        do {
            isValid = true;
            name = InputModule.getStringInput("Enter Software Name:");
            for(Software software : list){
                if(software.getName().equals(name)){
                    System.out.println("The Software already present in the software list!");
                    isValid = false;
                    break;
                }
            }
        }while(!isValid);

        return name;
    }
}
