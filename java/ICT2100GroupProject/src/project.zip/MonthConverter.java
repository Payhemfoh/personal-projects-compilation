public class MonthConverter {
    public static final String MONTH[] = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
    public static final int DAYSPERMONTH[] = {31,28,31,30,31,30,31,31,30,31,30,31};

    public static String convertMonth(int month){
        return MONTH[month-1];
    }

    public static boolean checkDay(int day,String month){
        int monthIndex = 0;
        boolean isValid = false;

        //get the index of month to match the day
        for(int i=0;i<MONTH.length;++i){
            if(month.equals(MONTH[i]))
                monthIndex = i;
        }

        if(day>0 && day<=DAYSPERMONTH[monthIndex]){
            isValid = true;
        }

        return isValid;
    }

    public static boolean checkDay(int day,int month){
        boolean isValid = false;

        if(day>0 && day<=DAYSPERMONTH[month-1]){
            isValid = true;
        }

        return isValid;
    }
}
