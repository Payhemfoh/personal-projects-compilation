public class Software implements Printable{
    //private variable in software 
    private String name;
    private String type;
    private double ramRequirement;
    private String expireDate;
    
    public Software(){//default constructor
        this("","",0,"");
    }
    public Software(String n,String t){this(n,t,0.0,"");}
    public Software(Software obj){this(obj.getName(),obj.getType(),obj.getRamRequirement(),obj.getExpireDate());}
    public Software(String n, String t,double r, String e) {//overloaded constructor
        setName(n);
        setType(t);
        setRamRequirement(r);
        setExpireDate(e);
    }

    
    //setter
    public void setName(String n){
        if(n == null || n.trim().equals(""))
            name="Unknown software";
        else
            name = n;
    }
    public void setType(String t){type = t;}
    public void setRamRequirement(double r){
        if(r<0 || r>64){
            ramRequirement = 0;
        }
        ramRequirement = r;
    }
    public void setExpireDate(String e){
        if(e==null || e.trim().equals(""))
            expireDate = "none";
        else
            expireDate = e;
    }
 
    //getter
    public String getName(){return name;}
    public String getType(){return type;}
    public double getRamRequirement(){return ramRequirement;}
    public String getExpireDate(){return expireDate;}

    @Override
    public String toString(){//format the value to store inside the file
        return (getName() + "," + getType() + "," + getRamRequirement() + "," + getExpireDate());
    }

    @Override
    public boolean equals(Object obj){//check the new or edit object is unique to existing object
        boolean isSame = false;
        
        if(!(obj instanceof Software)){
            return false;
        }

        Software temp = (Software) obj;

        if(temp.getName().equals(this.name) && temp.getType().equals(this.type)){
            isSame = true;
        }
        
        return isSame;
    }

    /**
     * this method used to print the information of software in console line-by-line
     */
    @Override
    public void print(){
        //display all the object in console
        System.out.printf("Name: %s\n",name);
        System.out.printf("Type: %s\n",type);
        System.out.printf("Ram Requirement:%.2f GB\n",this.ramRequirement);
        System.out.printf("Expire Date: %s\n",expireDate);
    }

}