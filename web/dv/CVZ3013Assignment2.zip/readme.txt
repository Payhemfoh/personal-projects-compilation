---------------------------------------------------------
Author: 	0198889 Chun Wei Yi		0198889@student.kdupg.edu.my
		0199053 Yeoh Pei Xian		0199053@student.kdupg.edu.my
		0205507 Tan Ee Yee		0205507@student.kdupg.edu.my
		0205930 Foh Wei Lian Willian	0205930@student.kdupg.edu.my

Campus:		UOW Malaysia KDU Penang
Subject:	CVZ3013 Data Visualization for Web
Instructor:	Assoc. Prof. Dr. J. Joshua
---------------------------------------------------------
The zip file contains:
1. data file (twitchdata.csv)
2. source code (CVZ3013Assignment2.html)
3. report for assignment which contains cover page and marking schema
---------------------------------------------------------

What is this?
-> This is the source code for data visualization assignment 2 which the graph is designed and produced with d3.js based on a set of data.

url of dataset:
-> https://www.kaggle.com/aayushmishra1512/twitchdata

Step to install and view the files
1. Install XAMPP
2. Open XAMPP
3. Open file explorer and access to htdocs folder in xampp folder (default: C:/xampp/htdocs/)
4. Put the data file (.csv) and source code (.html) into htdocs
5. Open web browser
6. Access the files from localhost (default: http://localhost/CVZ3013Assignment2.html)